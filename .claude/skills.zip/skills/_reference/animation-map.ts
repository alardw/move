/**
 * Animation Map
 *
 * Maps ComponentClass → animation wiring. The class IS the lookup key.
 * No separate pattern taxonomy — the class already encodes the decision.
 *
 * Actual animation values live in `defaultAnimations` (src/animation/types.ts).
 * This file describes the wiring — how to connect a hook to a component.
 * Component-specific hooks (e.g. useCarouselAnimation) are not mapped here;
 * the spec references them directly.
 */

import type { ComponentClass } from './spec-type';

// =============================================================================
// Class animation definition
// =============================================================================

export interface ClassAnimation {
  /** Hook that implements the animation (null = no animation) */
  hook: string | null;
  /** Config type the hook accepts (from src/animation/types.ts) */
  configType: string | null;
  /** What the hook returns */
  returns: string | null;
  /** Default preset key in `defaultAnimations` (src/animation/types.ts) */
  defaultPreset: string | null;
  /** Which slot(s) the animation targets */
  targetSlots: string[];
  /** Whether Presence is needed for mount/unmount coordination */
  needsPresence: boolean;
  /** How to wire the hook into a component */
  wiring: string[];
}

export const CLASS_ANIMATION: Record<ComponentClass, ClassAnimation> = {
  presentational: {
    hook: null,
    configType: null,
    returns: null,
    defaultPreset: null,
    targetSlots: [],
    needsPresence: false,
    wiring: [],
  },

  interactive: {
    hook: 'useInteractiveAnimate',
    configType: 'ElementAnimate',
    returns: '{ ref, handlers }',
    defaultPreset: 'defaultAnimations.element',
    targetSlots: ['root'],
    needsPresence: false,
    wiring: [
      'Merge hook ref with factory ref via useMergedRef.',
      'Merge each handler (onMouseEnter/Leave/Down/Up, onKeyDown/Up) — call hook handler first, then user callback.',
      'Pass `animate` prop as config, `defaultAnimations.element` as defaults, `disabled` flag.',
      'When animate === false, pass { hover: false, press: false } to disable.',
    ],
  },

  input_toggle: {
    hook: 'useToggleAnimation',
    configType: 'IndicatorAnimate',
    returns: '{ rootRef, indicatorRef, animateChecked, animateUnchecked, pressHandlers }',
    defaultPreset: 'defaultAnimations.indicator',
    targetSlots: ['root', 'indicator'],
    needsPresence: false,
    wiring: [
      'rootRef → merge with factory ref.',
      'indicatorRef → attach to indicator slot element.',
      'Call animateChecked() / animateUnchecked() on state change.',
      'Spread pressHandlers (onMouseDown/Up/Leave) on root element.',
    ],
  },

  input_popup: {
    hook: 'usePopupAnimation',
    configType: 'PopupAnimate',
    returns: '{ contentRef, innerRef }',
    defaultPreset: 'defaultAnimations.popup',
    targetSlots: ['content'],
    needsPresence: true,
    wiring: [
      'contentRef → attach to portal/content wrapper.',
      'innerRef → attach to inner content element (enables stagger on children).',
      'Receives isClosing + onCloseComplete from component context for exit coordination.',
      'Config flows: Root animate prop → mergeAnimateConfig() → context → Content sub-component.',
    ],
  },

  input_plain: {
    hook: null,
    configType: null,
    returns: null,
    defaultPreset: null,
    targetSlots: [],
    needsPresence: false,
    wiring: [],
  },

  disclosure: {
    hook: 'useExpandAnimation',
    configType: 'ContentAnimate',
    returns: '{ contentRef, isOpen, toggle }',
    defaultPreset: 'defaultAnimations.content',
    targetSlots: ['content'],
    needsPresence: false,
    wiring: [
      'contentRef → attach to content slot element.',
      'Hook measures content height and manages the transition internally.',
    ],
  },

  overlay_layer: {
    hook: 'useLayerAnimation',
    configType: 'LayerAnimate',
    returns: '{ contentRef, backdropRef, isOpen }',
    defaultPreset: 'defaultAnimations.layer',
    targetSlots: ['content', 'overlay'],
    needsPresence: true,
    wiring: [
      'contentRef → attach to overlay content element.',
      'backdropRef → attach to backdrop element.',
      'Content uses defaultAnimations.layer, backdrop uses defaultAnimations.layerBackdrop.',
    ],
  },

  overlay_popup: {
    hook: 'usePopupAnimation',
    configType: 'PopupAnimate',
    returns: '{ contentRef, innerRef }',
    defaultPreset: 'defaultAnimations.popup',
    targetSlots: ['content'],
    needsPresence: true,
    wiring: [
      'contentRef → attach to portal/content wrapper.',
      'innerRef → attach to inner content element (enables stagger on children).',
      'Receives isClosing + onCloseComplete from component context for exit coordination.',
      'Config flows: Root animate prop → mergeAnimateConfig() → context → Content sub-component.',
    ],
  },

  display: {
    hook: null,
    configType: null,
    returns: null,
    defaultPreset: null,
    targetSlots: [],
    needsPresence: false,
    wiring: ['No default. Spec picks hook and wiring as needed.'],
  },
} as const;

// =============================================================================
// Additional shared mechanism: sliding indicator
//
// Not tied to a class — used as an *additive* mechanism by components
// that also have a class animation (e.g. Tabs = disclosure + slidingIndicator,
// ToggleGroup = interactive + slidingIndicator, Pagination = interactive + slidingIndicator).
// =============================================================================

export const SLIDING_INDICATOR = {
  hook: 'useSlidingIndicator',
  returns: '{ indicatorRef, update }',
  wiring: [
    'containerRef → parent element containing the items.',
    'activeSelector → CSS selector for the active item (e.g. \'[data-state="active"]\').',
    'Optional track: "width" | "height" — direction to track.',
    'indicatorRef → the sliding element. Hook positions it automatically.',
  ],
} as const;
