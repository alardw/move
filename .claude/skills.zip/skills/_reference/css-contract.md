# CSS Module Contract

## Token placement

Component tokens go on `.root` (not `:root`) so they resolve semantic tokens in the element's local scope, enabling scoped ThemeProvider to work:

```css
.root {
  /* Component tokens — resolve in local scope */
  --move-button-primary-bg: var(--move-primary);
  --move-button-primary-bg-hover: var(--move-primary-hover);
  --move-button-primary-fg: var(--move-primary-fg);

  /* Base styles */
  display: inline-flex;
  align-items: center;
}
```

## Data-attribute selectors

Use `data-*` attributes for variant/size/state styling:

```css
/* Variant — include :not() fallback for default */
.root[data-variant='primary'],
.root:not([data-variant]) { /* default variant */ }
.root[data-variant='secondary'] { /* ... */ }

/* Size — include :not() fallback for default */
.root[data-size='sm'] { /* ... */ }
.root[data-size='md'], .root:not([data-size]) { /* default size */ }
.root[data-size='lg'] { /* ... */ }

/* State */
.root[data-state='checked'] { /* ... */ }
.root[data-state='open'] { /* ... */ }
```

## CSS variable naming

```
--move-{component}-{property}
--move-{component}-{variant}-{property}
--move-{component}-{slot}-{property}
```

Examples:
```css
--move-button-primary-bg
--move-checkbox-size
--move-accordion-trigger-bg-hover
--move-dialog-content-radius
```

## Design token references

Always reference design tokens, never hard-code colors or spacing:

```css
/* Good */
background-color: var(--move-primary);
padding: var(--move-spacing-md);
border-radius: var(--move-rounded-md);
font-family: var(--move-font-body);

/* Bad */
background-color: #3b82f6;
padding: 16px;
border-radius: 8px;
```

## Slot class naming

Each class in the CSS Module must match a slot name used in the factory:

```css
/* Slots: ['root', 'indicator', 'icon'] */
.root { /* ... */ }
.indicator { /* ... */ }
.icon { /* ... */ }
```

Additional utility classes (like `.wrapper`) are allowed but are not slots — they are referenced via `styles.wrapper` directly, not through `cx()`.

## Animation prohibition

**No CSS animations** for state/entrance/exit. Never use:
- `@keyframes`
- `animation` property
- `transition` for state changes, entrances, or exits

All motion goes through the anime.js-based animation system.

**Exception:** CSS `transition` is acceptable for simple hover color/background changes on non-animated elements (e.g. close button hover).

## Focus and disabled patterns

```css
/* Focus ring */
.root:focus-visible {
  outline: var(--move-focus-ring);
  outline-offset: var(--move-focus-ring-offset);
}

/* Disabled */
.root:disabled,
.root[data-disabled] {
  opacity: var(--move-disabled-opacity);
  pointer-events: none;
}
```
