/**
 * Component Spec Type Definitions
 *
 * The typed contract between human decisions (spec) and mechanical generation.
 * All specs must satisfy `ComponentSpec`.
 */

// =============================================================================
// Schema version — increment on breaking spec changes
// =============================================================================

export const SPEC_SCHEMA_VERSION = 1 as const;

// =============================================================================
// Component classification
// =============================================================================

export type ComponentClass =
  | 'presentational'
  | 'interactive'
  | 'input_toggle'
  | 'input_popup'
  | 'input_plain'
  | 'disclosure'
  | 'overlay_layer'
  | 'overlay_popup'
  | 'display';

// =============================================================================
// Behavioral patterns
// =============================================================================

/** Controlled/uncontrolled state pattern */
export type ControlledPattern =
  | 'open'      // open / defaultOpen / onOpenChange
  | 'value'     // value / defaultValue / onValueChange
  | 'checked'   // checked / defaultChecked / onCheckedChange
  | null;

/** Keyboard interaction pattern */
export type KeyboardPattern =
  | 'toggle'    // Space/Enter toggles
  | 'linear'    // Arrow up/down navigates list
  | 'roving'    // Arrow keys rove focus among items
  | 'typeahead' // Typing filters/searches
  | 'grid'      // Arrow keys in 2D grid
  | null;

/** Focus management pattern */
export type FocusPattern =
  | 'self'       // Component itself is focusable
  | 'trap'       // Focus trapped within (overlays)
  | 'roving'     // Focus roves among children
  | 'delegated'  // Focus delegated to child input
  | null;

/** Form integration type */
export type FormType =
  | 'native-name'   // Standard <input name="...">
  | 'hidden-input'  // Hidden input for form submission
  | null;

// =============================================================================
// Structural definitions
// =============================================================================

/** A named slot in the component anatomy */
export interface SlotDef {
  /** Slot name (e.g. 'root', 'indicator', 'content') */
  name: string;
  /** HTML element or Radix primitive this slot renders */
  element: string;
  /** Brief description of purpose */
  description: string;
}

/** A public prop definition */
export interface PropDef {
  /** Prop name */
  name: string;
  /** TypeScript type as string */
  type: string;
  /** Default value (if any) */
  default?: string;
  /** Whether this is a Move-specific prop (goes in moveProps/defaults) */
  moveSpecific: boolean;
  /** Brief description */
  description: string;
}

/** A CSS custom property declaration */
export interface TokenDeclaration {
  /** Full token name (e.g. '--move-button-primary-bg') */
  name: string;
  /** Value — MUST reference var(--move-*) semantic tokens */
  value: string;
  /** What this token controls */
  description: string;
}

/** A node in the component's render tree anatomy */
export interface AnatomyNode {
  /** Slot name (must match a SlotDef) */
  slot: string;
  /** data-* attributes set on this element */
  dataAttributes?: string[];
  /** ARIA attributes set on this element */
  ariaAttributes?: string[];
  /** Child anatomy nodes */
  children?: AnatomyNode[];
}

/** Animation binding for a slot */
export interface AnimationBinding {
  /** Slot this animation applies to */
  slot: string;
  /** Animation hook to use */
  hook: string;
  /** Animation config type (e.g. 'ElementAnimate', 'IndicatorAnimate') */
  configType: string;
  /** Default animation preset key from defaultAnimations */
  defaultPreset?: string;
}

// =============================================================================
// Sub-component definition (for compound components)
// =============================================================================

export interface SubComponentDef {
  /** Sub-component display name (e.g. 'Trigger', 'Content') */
  name: string;
  /** Slots owned by this sub-component */
  slots: SlotDef[];
  /** Props for this sub-component */
  props: PropDef[];
  /** Whether this sub-component uses the factory (vs plain FC) */
  usesFactory: boolean;
  /** Radix primitive this wraps (if any) */
  radixPrimitive?: string;
  /** Brief description */
  description: string;
}

// =============================================================================
// Internationalization
// =============================================================================

/** A translatable label exposed via the component's `labels` prop */
export interface LabelDef {
  /** Label key used in the labels prop object (e.g. 'close', 'next', 'dropzone') */
  key: string;
  /** English default value */
  default: string;
  /** Where this label is used */
  description: string;
}

// =============================================================================
// Testing section
// =============================================================================

export interface TestingSpec {
  /** Key behaviors to test */
  behaviors: string[];
  /** Keyboard interactions to test */
  keyboard?: string[];
  /** ARIA expectations to verify */
  aria?: string[];
  /** Form integration tests */
  form?: string[];
  /** Animation tests */
  animation?: string[];
}

// =============================================================================
// The spec itself
// =============================================================================

export interface ComponentSpec {
  /** Schema version — always SPEC_SCHEMA_VERSION */
  schemaVersion: typeof SPEC_SCHEMA_VERSION;

  /** Component display name (PascalCase) */
  name: string;

  /** Component class — determines template and default behaviors */
  componentClass: ComponentClass;

  /** Source category folder (e.g. 'form', 'overlay', 'core') */
  category: string;

  /** Brief one-line description */
  description: string;

  // --- Structure ---

  /** Whether this is a compound component with sub-components */
  compound: boolean;

  /** Root element HTML tag or Radix primitive */
  rootElement: string;

  /** All slots (for simple components) */
  slots: SlotDef[];

  /** Sub-components (for compound components) */
  subComponents?: SubComponentDef[];

  /** Root-level props */
  props: PropDef[];

  /** Render tree anatomy */
  anatomy: AnatomyNode;

  // --- Behavior ---

  /** Controlled state pattern */
  controlled: ControlledPattern;

  /** Keyboard interaction pattern */
  keyboard: KeyboardPattern;

  /** Focus management pattern */
  focus: FocusPattern;

  /** Form integration type */
  formType: FormType;

  /** Whether component supports asChild (Slot) rendering */
  asChild: boolean;

  // --- Animation ---

  /** Animation bindings (empty array = no animation) */
  animations: AnimationBinding[];

  // --- Styling ---

  /** Component CSS tokens — all values MUST reference var(--move-*) */
  tokens: TokenDeclaration[];

  /** Variant prop values */
  variants: Record<string, string[]>;

  /** Size prop values */
  sizes: string[];

  // --- Internationalization ---

  /** Translatable labels exposed via `labels` prop (empty array = no labels) */
  labels: LabelDef[];

  // --- Dependencies ---

  /** Radix primitive used (if any) */
  radixPrimitive?: string;

  /** Whether component uses a headless hook (use{Name}.ts) */
  hasHook: boolean;

  /** Engine imports needed */
  engineImports: string[];

  /** Animation imports needed */
  animationImports: string[];

  // --- Testing ---

  /** Test expectations */
  testing: TestingSpec;
}
