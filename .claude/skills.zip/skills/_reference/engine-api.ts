/**
 * Engine & Animation API Reference
 *
 * Available exports from src/engine/ and src/animation/.
 */

// =============================================================================
// Engine exports (from src/engine/index.ts)
// =============================================================================

export const ENGINE_EXPORTS = {
  factory: {
    withMoveComponent: 'Factory function for creating Move components. Handles forwardRef, default props, slot-props, and attrs stripping.',
  },
  context: {
    MoveProvider: 'Global context provider for slot-props overrides.',
    useMoveContext: 'Hook to access global slot-props for a component.',
  },
  hooks: {
    useMergedRef: 'Merges multiple refs into a single ref callback.',
    useControlledState: 'Manages controlled vs uncontrolled state pattern.',
  },
  utils: {
    mergeSlotProps: 'Merges multiple SlotProps objects.',
    createCx: 'Creates a CSS Module class resolver function.',
    createSp: 'Creates a slot-props merge function.',
  },
  types: {
    SlotProps: 'Props that can be applied to any slot element.',
    SlotPropsMap: 'Instance-level slot-props overrides keyed by slot name. Generic: SlotPropsMap<TSlots>.',
    GlobalSlotProps: 'Global slot-props keyed by component name, then slot name.',
    CxFn: 'CSS Module class resolver function type. Generic: CxFn<TSlots>.',
    SpFn: 'Slot-props merge function type. Generic: SpFn<TSlots>.',
    SetupContext: 'Context passed to setup() functions. Generic: SetupContext<TSlots, TProps, TRef>.',
    SetupReturn: 'Value returned from setup(): { render(): ReactNode }.',
    MoveComponentOptions: 'Options for withMoveComponent. Generic: MoveComponentOptions<TSlots, TProps, TRef, TSubs>.',
    MoveProviderProps: 'Props for MoveProvider component.',
    UseControlledStateOptions: 'Options for useControlledState hook.',
  },
} as const;

// =============================================================================
// Animation exports (from src/animation/index.ts)
// =============================================================================

export const ANIMATION_EXPORTS = {
  hooks: {
    useAnimateConfig: 'Low-level hook for applying animation configurations.',
    useInteractiveAnimate: 'Hook for interactive elements — hover/press animations. Returns { ref, handlers }.',
    useToggleAnimation: 'Hook for toggle controls — checked/unchecked animations. Returns { rootRef, indicatorRef, animateChecked, animateUnchecked, pressHandlers }.',
    useExpandAnimation: 'Hook for expandable panels — open/close height+opacity. Returns { contentRef, isOpen, toggle }.',
    useSlidingIndicator: 'Hook for sliding indicator (Tabs, Pagination). Returns { containerRef, indicatorRef, activeIndex }.',
    useCarouselAnimation: 'Hook for carousel slide transitions.',
    usePopupAnimation: 'Hook for popup content — enter/exit with stagger. Returns { contentRef, isOpen }.',
    useLayerAnimation: 'Hook for overlay content — enter/exit for content + backdrop. Returns { contentRef, backdropRef, isOpen }.',
  },
  presence: {
    Presence: 'Component for managing enter/exit animations with mount/unmount lifecycle.',
    usePresence: 'Hook to access presence context. Returns [isPresent, safeToRemove].',
    useIsPresent: 'Hook to check if element is present (boolean).',
  },
  utils: {
    prefersReducedMotion: 'Check if user prefers reduced motion.',
    resolveEasing: 'Resolve easing preset name to anime.js easing value.',
    toAnimeParams: 'Convert Animation config to anime.js params object.',
    toInstantParams: 'Convert Animation to instant params for reduced motion.',
    mergeAnimateConfig: 'Merge animation configs with defaults.',
    getInitialStyles: 'Extract initial CSS styles from Animation config.',
  },
  springs: {
    springs: 'Object with spring presets: snappy, quick, poppy, gentle, slow, lazy, jelly, stiff.',
    easings: 'Array of all easing preset names.',
    getEase: 'Helper to get ease value from preset name.',
    isSpring: 'Helper to check if preset is a spring (vs easing curve).',
  },
  types: {
    AnimationPreset: "'none' | SpringPreset | Easing",
    AnimatableValue: 'T | { value: T; easing?: AnimationPreset }',
    AnimationProperties: 'Properties that can be animated (scale, x, y, opacity, etc.).',
    Animation: 'Single animation definition with properties and timing.',
    StaggerConfig: 'Stagger configuration: { delay?: number; from?: "first" | "last" | "center" }.',
    AnimateConfig: 'Full animation configuration: enter, exit, hover, press, open, close, checked, unchecked, stagger.',
    ElementAnimate: 'For interactive elements: enter, exit, hover, press.',
    ContentAnimate: 'For expandable content: enter, exit, open, close, stagger.',
    IndicatorAnimate: 'For toggle controls: enter, exit, press, checked, unchecked.',
    LayerAnimate: 'For overlay content: enter, exit.',
    PopupAnimate: 'For popup content: enter, exit, stagger.',
    PopupItemAnimate: 'For popup items: enter, exit, hover.',
    ListAnimate: 'For list containers: enter, exit, stagger.',
    ListItemAnimate: 'For list items: enter, exit, hover, press.',
    CarouselAnimate: 'For carousel: enter.',
  },
  constants: {
    defaultAnimations: 'Default animation configs: element, layer, layerBackdrop, content, popup, popupItem, indicator, carousel.',
    DEFAULT_DURATION: 'Default animation duration (200ms).',
  },
} as const;

// =============================================================================
// Import patterns
// =============================================================================

export const IMPORT_PATTERNS = {
  engine: {
    internal: "import { withMoveComponent, useMergedRef } from '../../../engine';",
    internalTypes: "import type { SlotPropsMap } from '../../../engine/types';",
  },
  animation: {
    hooks: "import { useInteractiveAnimate } from '../../../animation';",
    types: "import type { ElementAnimate } from '../../../animation/types';",
    defaults: "import { defaultAnimations } from '../../../animation/types';",
    presence: "import { Presence } from '../../../animation';",
  },
} as const;
