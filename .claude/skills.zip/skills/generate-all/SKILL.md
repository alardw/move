# Generate All — Full Component Generation Pipeline

Run all generation skills for a component in sequence. Requires an existing spec file.

---

## How to Run

**Input:** A component name (e.g. "Badge", "Checkbox").

**Output:** All generated files written/updated:
- `{Name}.tsx` — component implementation
- `{Name}.module.css` — CSS module styles
- `index.ts` — barrel exports
- `use{Name}.ts` — headless hook (if spec declares `hasHook: true`)
- `{Name}.meta.ts` — component metadata
- `{Name}.stories.tsx` — Storybook story
- `{Name}.test.tsx` — test file
- `{Name}.report.md` — validation report
- `src/index.ts` — updated with component exports

**REFUSES if:** `{Name}.spec.ts` does not exist. Run `/spec {Name}` first.

---

## Process

Run these skills in order. Each step must complete before the next begins, because later steps read files produced by earlier ones.

### Step 1 — `/generate {Name}`
Generates `.tsx`, `.module.css`, `index.ts`, `use{Name}.ts` (if applicable), updates `src/index.ts`.

### Step 2 — `/generate-meta {Name}`
Generates `.meta.ts` from the component source.

### Step 3 — `/generate-story {Name}`
Generates `.stories.tsx` from the component source.

### Step 4 — `/generate-test {Name}`
Generates `.test.tsx` from the spec and component source.

### Step 5 — `/validate {Name}`
Validates all generated files and writes `.report.md`.

---

## Rules

1. **Run in order** — each step depends on output from previous steps
2. **Stop on failure** — if any step fails, report the failure and stop
3. **Follow each skill's own rules** — this skill only orchestrates; each sub-skill's SKILL.md governs its output
4. **Spec must already exist** — this skill does not generate or modify specs
