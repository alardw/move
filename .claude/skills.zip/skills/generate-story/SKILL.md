# Generate Story — Storybook Story Generator

Generate a Storybook story file for a Move component by reading its source.

---

## How to Run

**Input:** A component name (e.g. "Button", "Select", "Dialog").

**Output:** `{Name}.stories.tsx` written next to the component.

---

## Process

### Step 1 — Locate the component

Find `src/components/{category}/{Name}/{Name}.tsx`. Use glob if category unknown:
```
src/components/**/{Name}/{Name}.tsx
```

Also check for demo file: `demo/src/demos/{Name}Demo.tsx` (reference for compound composition).

### Step 2 — Read and extract metadata

Read `{Name}.tsx` and extract:

| Field | Where to find it |
|-------|-----------------|
| `defaults` | Object literal in `withMoveComponent({ defaults: { ... } })` |
| `moveProps` | Array in `withMoveComponent({ moveProps: [...] })` |
| `slots` | Array in `withMoveComponent({ slots: [...] })` |
| Props interface | `export interface {Name}Props extends Record<string, unknown> { ... }` |
| Event handlers | Props starting with `on` + uppercase |
| Category | File path segment after `src/components/` |
| Component pattern | Simple (single export) or compound (namespace object) |

### Step 3 — Build the story

#### Imports

```tsx
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';
import { {Name} } from './{Name}';
```

#### Meta

```tsx
const meta: Meta = {
  title: '{Category}/{Name}',
  component: {Name},
  args: { ... },
  argTypes: { ... },
  render: (args) => <{Name} {...args} />,  // simple components only
};
export default meta;
```

#### Args

**Do NOT put default values in `args`** — they pollute the generated code sample. Only include:
- `fn()` for every event handler prop
- `children: '{Name}'` for components rendering children as text
- Props required for rendering but without defaults

#### ArgTypes

Map types to controls:

| Prop type | Control |
|-----------|---------|
| String literal union | `control: 'select', options: [...]` |
| `boolean` | `control: 'boolean'` |
| `string` | `control: 'text'` |
| `number` | `control: 'number'` |
| `React.ReactNode` (children) | `control: 'text'` |
| Event handler | `action: 'eventName'` |
| Complex objects | Omit from argTypes |
| Animation config | Omit from argTypes |

For props with defaults, add `table.defaultValue`:
```tsx
size: {
  control: 'select',
  options: ['sm', 'md', 'lg'],
  table: { defaultValue: { summary: 'md' } },
},
```

**Skip these from argTypes:** `className`, `style`, `sp`, `animate`, `asChild`

#### Render function

**Simple:** `render: (args) => <{Name} {...args} />`

**Compound:** Compose sub-components in standard usage pattern:
```tsx
render: (args) => (
  <{Name}.Root onValueChange={args.onValueChange}>
    <{Name}.Trigger>...</{Name}.Trigger>
    <{Name}.Content>...</{Name}.Content>
  </{Name}.Root>
),
```

#### Story export

Single story — controls handle variants:
```tsx
type Story = StoryObj;
export const Default: Story = {};
```

### Step 4 — Write the file

Write to `src/components/{category}/{Name}/{Name}.stories.tsx`

---

## Rules

1. **Provenance comment on line 1** — `// Generated from {Name}.spec.ts (schemaVersion: {N}, specHash: {XXXX})`. If no spec, use `// Generated from {Name}.tsx (sourceHash: {XXXX})`.
2. **Always read component source first** — never guess prop types or defaults
3. **Use demo file as reference** for compound component composition
4. **One Default story** — controls handle all variants
5. **No argTypes for complex props** (style, sp, animate, className)
6. **Use `fn()` from `'storybook/test'`** for all event handler args
7. **Compound components** — only Root-level callbacks in args/argTypes
