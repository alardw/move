# Generate — Component Code Generator

Generate component source files from a `.spec.ts` specification. **REFUSES without a spec file.**

---

## How to Run

**Input:** A component name (e.g. "Badge", "Checkbox").

**Output:** Generated files written to disk:
- `{Name}.tsx` — component implementation
- `{Name}.module.css` — CSS module styles
- `index.ts` — barrel exports
- `use{Name}.ts` — headless hook (if spec declares `hasHook: true`)
- `src/index.ts` — updated with component exports

**REFUSES if:** `{Name}.spec.ts` does not exist in the component directory.

---

## Process

### Step 1 — Locate and read spec

Find `src/components/{category}/{Name}/{Name}.spec.ts`. If not found, REFUSE and tell the user to run `/spec {Name}` first.

Read the spec file and extract the `ComponentSpec` object.

### Step 2 — Load reference contracts

Read these files for generation rules:

| File | Purpose |
|------|---------|
| `_reference/factory-contract.md` | `withMoveComponent` signature, setup pattern, render pattern |
| `_reference/css-contract.md` | Token placement, data-attribute selectors, animation prohibition |
| `_reference/engine-api.ts` | Available imports |
| `_reference/animation-map.ts` | Animation hook details |

### Step 3 — Generate component file (`{Name}.tsx`)

Follow the factory contract exactly:

1. `'use client'` directive at line 1 (must be first — bundlers require it before any other statement)
2. Provenance comment on line 2: `// Generated from {Name}.spec.ts (schemaVersion: {N}, specHash: {XXXX})`
3. Imports from `../../../engine` (factory, hooks, types)
4. Imports from `../../../animation` (hooks, types) if spec has animations
5. Radix import if spec declares `radixPrimitive`
6. CSS module import
7. Type exports (variant, size, props)
8. Props interface `extends Record<string, unknown>`
9. Labels type and prop (if spec has `labels`): generate `{Name}Labels` type with all keys, `DEFAULT_LABELS` const with defaults, add `labels?: Partial<{Name}Labels>` prop, merge with defaults in setup
10. `withMoveComponent` call with:
    - `name` from spec
    - `styles` from CSS module
    - `slots` from spec
    - `defaults` from props with defaults
    - `moveProps` from props marked `moveSpecific: true` (excluding those in defaults)
    - `subComponents` if compound
11. `setup()` function with:
    - Animation hooks (based on spec `animations`)
    - Headless hook call (if `hasHook`)
    - Event handler merging (animation handlers + user handlers)
    - `render()` following the exact sp/cx/attrs pattern from factory-contract.md

### Step 4 — Generate CSS module (`{Name}.module.css`)

Follow css-contract.md exactly:

1. Component tokens on `.root` (from spec `tokens`)
2. Base styles on `.root`
3. Variant styles via `[data-variant='...']` (from spec `variants`)
4. Size styles via `[data-size='...']` (from spec `sizes`)
5. State styles via `[data-state='...']` (if applicable)
6. Focus/disabled patterns
7. Sub-slot styles (from spec `slots`)
8. All values reference design tokens — no hardcoded hex/px/rem for colors/spacing. If the spec has a value with no exact token, snap to the nearest primitive token in the scale.

**Provenance header:**
```css
/* Generated from {Name}.spec.ts (schemaVersion: {N}, specHash: {XXXX}) */
```

### Step 5 — Generate index.ts

```ts
// Generated from {Name}.spec.ts (schemaVersion: {N}, specHash: {XXXX})
export { {Name} } from './{Name}';
export type { {Name}Props, /* variant/size types */ } from './{Name}';
```

If hook exists:
```ts
export { use{Name} } from './use{Name}';
export type { Use{Name}Options, Use{Name}Return } from './use{Name}';
```

### Step 6 — Generate headless hook (if applicable)

If `spec.hasHook === true`, generate `use{Name}.ts`:

1. Import `useControlledState` from engine
2. Options interface with controlled state props
3. Return interface with state + actions
4. Hook implementation using `useControlledState`

### Step 7 — Update src/index.ts

Add exports for the component, types, and hook (if any) to `src/index.ts`.

---

## Class-specific templates

The `componentClass` from the spec determines the generation template:

| Class | Key template features |
|-------|----------------------|
| `presentational` | No animation, no hooks, single slot, simple render |
| `interactive` | `useInteractiveAnimate`, event handler merging, `useMergedRef`, optional `asChild` |
| `input_toggle` | `useToggleAnimation`, headless hook, hidden input for form, `data-state` |
| `input_popup` | `usePopupAnimation`, `Presence`, Radix primitive wrapping, `aria-expanded` |
| `input_plain` | Native input element, label association, form integration |
| `disclosure` | `useExpandAnimation`, compound with trigger/content, `aria-expanded` |
| `overlay_layer` | `useLayerAnimation`, `Presence`, Radix Dialog, focus trap, `role="dialog"` |
| `overlay_popup` | `usePopupAnimation`, `Presence`, Radix Popover/Dropdown |
| `display` | Varies — use spec's specific animation/structure decisions |

---

## Rules

1. **REFUSE without spec** — never generate without `{Name}.spec.ts`
2. **Follow factory-contract.md exactly** — sp/cx/attrs pattern, render order
3. **Follow css-contract.md exactly** — tokens on .root, data-attributes, no CSS animations
4. **Provenance headers on all files** — `Generated from {Name}.spec.ts (schemaVersion: N, specHash: XXXX)`
5. **All token values reference semantic tokens** — as specified in the spec
6. **Props interface extends Record<string, unknown>** — for every factory-based component
7. **No hardcoded values in CSS** — always `var(--move-*)` for colors/spacing/radius
