# Validate — Component & Theme Validator

Merged validation skill: component conformance, theme validation, spec drift detection, and registry management.

---

## How to Run

**Input:** One of:
- A component name (e.g. "Badge") — validate that component
- `"all"` — validate all components
- `"theme {name}"` or `"theme all"` — validate theme files
- `"registry"` — show registry status of all components
- Append `"fix"` to auto-fix failures (e.g. "Badge fix")

**Output:**
- `{Name}.report.md` written next to the component (for component validation)
- Stdout summary of results

---

## Component Validation

### Step 1 — Read files

1. `src/components/{category}/{Name}/{Name}.tsx` — component source
2. `src/components/{category}/{Name}/{Name}.module.css` — CSS module
3. `src/components/{category}/{Name}/index.ts` — barrel exports
4. `src/components/{category}/{Name}/use{Name}.ts` — headless hook (if exists)
5. `src/components/{category}/{Name}/{Name}.spec.ts` — spec (if exists)
6. `src/components/{category}/{Name}/{Name}.stories.tsx` — story (if exists)

### Step 2 — Run validation rules

#### A. Component File (`{Name}.tsx`)

| # | Rule | How to check |
|---|------|-------------|
| A1 | `'use client'` at line 1 | First line is `'use client';` |
| A2 | Props extends `Record<string, unknown>` | Every factory-based props interface |
| A3 | Move-specific props in `moveProps`/`defaults` | Cross-reference props interface vs moveProps + defaults keys |
| A4 | Default values in `defaults` object | No inline defaults in destructuring |
| A5 | `slots` array matches `sp()`/`cx()` calls | Every slot used, every used slot listed |
| A6 | `cx()` for every className on slotted elements | No raw `className={styles.foo}` |
| A7 | `sp()` called for every slot | Destructured as `{ className: spClass, style: spStyle, ...spRest }` |
| A8 | `{...attrs}` and `{...spRest}` on root | Both spread on root element |
| A9 | `ref` forwarded to root | `ref={ref}` or `ref={mergedRef}` |
| A10 | `data-variant`/`data-size`/`data-state` used | Where applicable |
| A11 | Import paths use `engine/` | No imports from `../core` |
| A12 | No Move-internal props leak to HTML | All Move-specific in moveProps/defaults |

#### B. CSS Module (`{Name}.module.css`)

| # | Rule |
|---|------|
| B1 | Matching `.{slotName}` class for every slot |
| B2 | Design token variables, no hard-coded values |
| B3 | Component tokens on `.root` not `:root` |
| B4 | Data-attribute selectors for variant/size/state |
| B5 | CSS variable naming: `--move-{component}-{property}` |
| B6 | No CSS `@keyframes`/`animation`/`transition` for state/entrance/exit |

#### C. Exports

| # | Rule |
|---|------|
| C1 | `index.ts` exports component + all types |
| C2 | Component added to `src/index.ts` |
| C3 | Headless hook exported (if exists) |

#### D. Storybook Story

| # | Rule |
|---|------|
| D1 | Story file exists (`{Name}.stories.tsx`) |
| D2 | Single Default story export |
| D3 | ArgTypes match component props |

#### E. Accessibility & i18n

| # | Rule |
|---|------|
| E1 | All user-visible strings come from `labels` prop with defaults (no hardcoded strings) |
| E2 | Built-in icons use `useResolvedIcon` |
| E3 | Essential icons have built-in fallbacks |
| E4 | Fallback children for icon slots |

#### F. Placement Consistency

| # | Rule |
|---|------|
| F1 | Component in valid category folder |
| F2 | `src/index.ts` path matches actual location |

### Step 3 — Spec drift detection (if spec exists)

Compare spec hash in the component's provenance header against the current spec file's hash. If they differ, the component may be out of date with the spec.

Also validate that:
- All spec tokens reference existing semantic tokens
- Spec's slots match component's slots
- Spec's props match component's props

### Step 4 — Write report

Write `src/components/{category}/{Name}/{Name}.report.md`:

```markdown
<!-- Validated: {timestamp} | sourceHash: {hash} | specHash: {hash or 'none'} -->
# {Name} — Validation Report

| Rule | Status | Notes |
|------|--------|-------|
| A1   | PASS   |       |
| A2   | PASS   |       |
| ...  | ...    | ...   |

Spec drift: {none | detected}
Issues: {count}
```

### Step 5 — Update registry

Update `src/components/specs.registry.ts` with the component's validation status.

---

## Theme Validation

When input starts with "theme":

### Rules

| # | Rule |
|---|------|
| A1 | No hardcoded hex colors in token values |
| A2 | All referenced primitives exist in primitives/colors.css |
| A3 | Non-color values (rgba, transparent) exempt from A1 |
| B1 | Theme implements all required ThemeTokens keys |
| B2 | No extra tokens beyond ThemeTokens interface |
| B3 | Animation config is complete |
| C1 | CSS defaults reference primitives |
| C2 | Every ThemeTokens key has a CSS default |
| D1 | Theme values do not reference semantic tokens |
| D2 | CSS defaults do not reference other semantic tokens |
| E1 | Theme has a name property |
| E2 | Token keys match naming convention |

### Files to read

- `src/styles/tokens/primitives/colors.css`
- `src/styles/tokens/semantic.css`
- `src/styles/themes/types.ts`
- `src/styles/themes/{name}.ts`

---

## Registry Mode

When input is "registry":

Read `src/components/specs.registry.ts` and output a summary table:

```
| Component | Category | Spec | Status |
|-----------|----------|------|--------|
| Badge     | misc     | yes  | valid  |
| Button    | core     | no   | no-spec|
| ...       | ...      | ...  | ...    |
```

---

## Fix Mode

When input includes "fix", after audit:

1. Fix failures in order: A → B → C → D → E → F
2. Apply fix procedures (see fix procedures in reference)
3. Re-run validation to confirm fixes

---

## Report staleness detection

`/validate` detects stale reports by comparing the `sourceHash` in the report header against the current source hash. If they differ, the report is regenerated.

---

## Important Notes

- Only flag actual violations, not style preferences
- For compound components, validate the main file containing all sub-components
- `sp` is auto-handled by factory — not needed in `moveProps`
- `className`, `style`, `children` don't need to be in `moveProps`
- Wrapper elements that aren't slots may use `styles.wrapper` directly
