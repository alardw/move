# Spec — Component Specification Generator

Create a typed `.spec.ts` file that captures all human decisions for a component. The spec is the approved contract between decisions and mechanical generation.

---

## How to Run

**Input:** A component name (e.g. "Badge", "Checkbox").

**Output:** `src/components/{category}/{Name}/{Name}.spec.ts` written to disk.

---

## Mode detection

The skill auto-detects the mode based on whether source exists:

### Extract mode (source exists)

Search for existing source in this order:
1. `src/original-components/**/{Name}/{Name}.tsx`
2. `src/components/**/{Name}/{Name}.tsx`

If found → **extract mode**:
- Read `{Name}.tsx`, `{Name}.module.css`, `index.ts`, `use{Name}.ts` (if exists)
- Mechanically extract: slots, props, defaults, moveProps, variants, sizes, controlled pattern, animation usage, tokens, Radix primitive, compound structure
- Infer componentClass from the extraction (animation hook used, ARIA attributes, form pattern)
- Look up category from the file path, or from the registry
- Present the extracted spec to the user for confirmation before writing
- The user may correct or override any extracted value

### Create mode (no source)

If no source found → **create mode**:
- Ask the user for: componentClass, category, description
- Fill class defaults from `_reference/` files (animation, a11y, keyboard, focus, form)
- Ask the user for component-specific decisions: slots, props, variants, sizes, tokens
- REFUSE if critical decisions are missing (componentClass, category, slots, props)

---

## Process

### Step 1 — Load reference data

Read these files for class defaults and available options:

| File | Purpose |
|------|---------|
| `_reference/spec-type.ts` | `ComponentSpec` type definition |
| `_reference/categories.ts` | Valid categories and placement rules |
| `_reference/animation-map.ts` | Class → animation wiring |
| `_reference/keyboard-map.ts` | Keyboard pattern → keys/behavior |
| `_reference/a11y-contract.ts` | Class → ARIA requirements |
| `_reference/form-patterns.ts` | Form integration patterns |
| `_reference/default-conventions.ts` | Token/size/variant defaults |
| `_reference/engine-api.ts` | Available engine/animation imports |
| `_reference/radix-primitives.ts` | Available Radix primitives |
| `_reference/tokens-semantic.ts` | Available semantic tokens |

### Step 2 — Gather decisions

**Extract mode:** Read the source and derive each field:

| Field | How to extract |
|-------|---------------|
| name | Component export name |
| componentClass | Infer from animation hook, ARIA, form pattern |
| category | From file path |
| slots | From `slots: [...]` in `withMoveComponent` |
| props | From props interface |
| defaults | From `defaults: {...}` in `withMoveComponent` |
| moveProps | From `moveProps: [...]` in `withMoveComponent` |
| variants | String literal union props with data-attribute selectors in CSS |
| sizes | Size union prop values |
| controlled | Presence of open/value/checked triads |
| tokens | `--move-{component}-*` declarations in `.module.css` |
| animations | Which animation hooks are imported and how they're wired |
| compound | Object.assign / object literal / subComponents export pattern |
| radixPrimitive | Radix imports |
| hasHook | Whether `use{Name}.ts` exists |
| anatomy | Render tree from `render()` |
| labels | Hardcoded user-visible strings (aria-label values, button text, placeholder text) |

**Create mode:** From user input + class defaults from `_reference/`.

### Step 3 — Apply class defaults

Use `_reference/animation-map.ts` to fill animation defaults based on `componentClass`.

Use `_reference/a11y-contract.ts` to fill accessibility defaults.

Use `_reference/default-conventions.ts` to fill token value defaults.

In extract mode, the extracted values take precedence over class defaults.

### Step 4 — Validate token values

Every `TokenDeclaration.value` must reference `var(--move-*)` semantic tokens from `_reference/tokens-semantic.ts`. If no exact token exists, snap to the nearest primitive in the scale rather than hardcoding a literal value.

### Step 5 — Compute spec hash

```ts
import { createHash } from 'crypto';
const specHash = createHash('md5').update(JSON.stringify(spec)).digest('hex').slice(0, 8);
```

### Step 6 — Write the spec file

Write to `src/components/{category}/{Name}/{Name}.spec.ts`:

```ts
// {Name}.spec.ts — Component specification
// specHash: {hash}

import type { ComponentSpec } from '../../../../.claude/skills/_reference/spec-type';
import { SPEC_SCHEMA_VERSION } from '../../../../.claude/skills/_reference/spec-type';

export const spec: ComponentSpec = {
  schemaVersion: SPEC_SCHEMA_VERSION,
  name: '{Name}',
  componentClass: '{class}',
  // ... all fields
};
```

---

## Rules

1. **Auto-detect mode** — check for existing source before asking the user anything
2. **Extract mode: present for confirmation** — show the extracted spec and let the user correct before writing
3. **Create mode: never guess critical decisions** — ask the user if componentClass, category, slots, or props are unclear
4. **All token values must reference semantic tokens** — `var(--move-*)` from `_reference/tokens-semantic.ts`
5. **Snap to nearest token** — if a value has no exact semantic token, use the nearest primitive in the scale (e.g. `0.375rem` → `var(--move-space-1)`). Do not introduce hardcoded values when a close token exists.
6. **Use class defaults** — fill animation, a11y, and token defaults from reference files based on componentClass
7. **Spec must satisfy ComponentSpec** — the output must type-check against the interface
8. **specHash in header comment** — compute and include for provenance tracking
9. **Deterministic output** — same inputs produce same output
